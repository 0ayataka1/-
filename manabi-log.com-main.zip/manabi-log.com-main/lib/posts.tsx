// lib/posts.ts
import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { remark } from 'remark';
import html from 'remark-html';

const postsDirectory = path.join(process.cwd(), 'content', 'posts');
const profilePath = path.join(process.cwd(), 'content', 'profile.md');

// ─── ブログ記事 ─────────────────────────

// すべての記事の slug を取得（ファイル名から）
export function getPostSlugs() {
  return fs.readdirSync(postsDirectory).filter((file) => file.endsWith('.md'));
}

// slug を元に1つの記事データを取得
export function getPostBySlug(slug: string) {
  const realSlug = slug.replace(/\.md$/, '');
  const fullPath = path.join(postsDirectory, `${realSlug}.md`);
  const fileContents = fs.readFileSync(fullPath, 'utf8');
  const { data, content } = matter(fileContents);

  return {
    slug: realSlug,
    meta: data,
    contentHtml,
  };
}

// 全記事を取得（一覧ページ用）
// ※ profile.md のように「記事一覧に出したくないもの」は
//   フロントマターに `exclude: true` を追加しておく
export async function getAllPosts() {
  const slugs = getPostSlugs();

  const posts = await Promise.all(
    slugs.map((slug) => getPostBySlug(slug.replace(/\.md$/, '')))
  );

  return posts
    .filter((post) => !post.meta.exclude) // ← exclude:true を除外
    .sort((a, b) => {
      return new Date(b.meta.date).getTime() - new Date(a.meta.date).getTime();
    });
}

// ─── プロフィール情報 ─────────────────────────

export async function getProfile() {
  const profilePath = path.join(process.cwd(), 'content', 'profile.md');
  const fileContents = fs.readFileSync(profilePath, 'utf8');
  const { data, content } = matter(fileContents);

  const processedContent = await remark().use(html).process(content);
  const contentHtml = processedContent.toString();

  return {
    ...data,
    contentHtml,
  };
}

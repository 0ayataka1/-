// pages/_app.tsx
import '../styles/globals.css'; // 必要に応じて
import type { AppProps } from 'next/app';

export default function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}

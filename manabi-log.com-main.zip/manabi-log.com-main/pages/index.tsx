// pages/index.tsx
import { GetStaticProps } from 'next';
import Link from 'next/link';
import React from 'react';
import { getAllPosts } from '../lib/posts';

export default function Index({ posts }: { posts: any[] }) {
  return (
    <main className="max-w-3xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Latest Posts</h1>
      <ul>
        {posts.map((p) => (
          <li key={p.slug} className="mb-4">
            <Link href={`/posts/${p.slug}`}>
              <a className="text-xl text-blue-700">{p.title}</a>
            </Link>
            <div className="text-sm text-gray-500">{p.date}</div>
          </li>
        ))}
      </ul>
    </main>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  const posts = getAllPosts();
  return { props: { posts } };
};

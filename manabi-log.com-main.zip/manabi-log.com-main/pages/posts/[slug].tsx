// pages/posts/[slug].tsx

import { GetStaticPaths, GetStaticProps } from 'next';
import { useRouter } from 'next/router';
import Head from 'next/head';
import { getAllPostSlugs, getPostBySlug } from '../../lib/posts';

type PostProps = {{
  slug: string;
  title: string;
  date: string;
  contentHtml: string;
};

export default function Post({ title, date, contentHtml }: PostProps) {
  const router = useRouter();

  if (router.isFallback) {
    return <div>読み込み中...</div>;
  }

  return (
    <div className="max-w-3xl mx-auto py-10 px-4">
      <Head>
        <title>{title} | まなびログ</title>
      </Head>
      <article>
        <h1 className="text-3xl font-bold mb-2">{title}</h1>
        <p className="text-sm text-gray-500 mb-6">{date}</p>
        <div
          className="prose max-w-none"
          dangerouslySetInnerHTML={{ __html: contentHtml }}
        />
      </article>
    </div>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const slugs = getAllPostSlugs(); // 例: ["my-first-post", "another-one"]

  const paths = slugs.map((slug) => ({
    params: { slug: slug.replace(/\.md$/, '') },
  }));

  return {
    paths,
    fallback: false, // falseだと404を表示する
  };
};

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const post = await getPostBySlug(params?.slug as string);

  return {
    props: {
      slug: post.slug,
      title: post.meta.title,
      date: post.meta.date,
      contentHtml: post.contentHtml, // ← remark でHTML変換したやつを返すようにlib/posts.tsを修正する必要あり
    },
  };
};



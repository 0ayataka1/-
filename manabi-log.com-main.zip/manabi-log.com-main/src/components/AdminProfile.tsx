import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase, Profile, FooterSettings } from '../lib/supabase';
import { User, Save, Upload, X, ArrowLeft, Mail, Globe, Github, Twitter, Linkedin, Building, FileText, Image, AlertCircle } from 'lucide-react';

export default function AdminProfile() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [footerSettings, setFooterSettings] = useState<FooterSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'footer'>('profile');
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const [profileForm, setProfileForm] = useState({
    display_name: '',
    bio: '',
    short_bio: '',
    avatar_url: '',
    twitter_url: '',
    github_url: '',
    linkedin_url: '',
    website_url: ''
  });

  const [footerForm, setFooterForm] = useState({
    company_name: '',
    company_description: '',
    contact_email: '',
    privacy_policy_url: '',
    terms_of_service_url: '',
    sitemap_url: '',
    copyright_text: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      await Promise.all([fetchProfile(), fetchFooterSettings()]);
    } catch (error) {
      console.error('データの取得に失敗しました:', error);
      setMessage({ type: 'error', text: 'データの取得に失敗しました' });
    } finally {
      setLoading(false);
    }
  };

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .limit(1)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // データが存在しない場合は空のフォームのまま
          console.log('プロフィールデータが存在しません');
          return;
        }
        throw error;
      }

      if (data) {
        const profileData = data;
        setProfile(profileData);
        setProfileForm({
          display_name: profileData.display_name || '',
          bio: profileData.bio || '',
          short_bio: profileData.short_bio || '',
          avatar_url: profileData.avatar_url || '',
          twitter_url: profileData.twitter_url || '',
          github_url: profileData.github_url || '',
          linkedin_url: profileData.linkedin_url || '',
          website_url: profileData.website_url || ''
        });
      }
    } catch (error) {
      console.error('プロフィールの取得に失敗しました:', error);
    }
  };

  const fetchFooterSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('footer_settings')
        .select('*')
        .limit(1)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // データが存在しない場合は空のフォームのまま
          console.log('フッター設定データが存在しません');
          return;
        }
        throw error;
      }

      if (data) {
        const footerData = data;
        setFooterSettings(footerData);
        setFooterForm({
          company_name: footerData.company_name || '',
          company_description: footerData.company_description || '',
          contact_email: footerData.contact_email || '',
          privacy_policy_url: footerData.privacy_policy_url || '',
          terms_of_service_url: footerData.terms_of_service_url || '',
          sitemap_url: footerData.sitemap_url || '',
          copyright_text: footerData.copyright_text || ''
        });
      }
    } catch (error) {
      console.error('フッター設定の取得に失敗しました:', error);
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('認証が必要です');

      console.log('プロフィール保存開始:', profileForm);

      if (profile) {
        // 更新
        console.log('プロフィール更新:', profile.id);
        const { error } = await supabase
          .from('profiles')
          .update({
            ...profileForm,
            updated_at: new Date().toISOString()
          })
          .eq('id', profile.id);

        if (error) throw error;
        console.log('プロフィール更新成功');
      } else {
        // 新規作成
        console.log('プロフィール新規作成');
        const { error } = await supabase
          .from('profiles')
          .insert([{
            ...profileForm,
            user_id: user.id
          }]);

        if (error) throw error;
        console.log('プロフィール作成成功');
      }

      await fetchProfile();
      setMessage({ type: 'success', text: 'プロフィールを保存しました' });
    } catch (error: any) {
      console.error('プロフィールの保存に失敗しました:', error);
      setMessage({ type: 'error', text: 'プロフィールの保存に失敗しました: ' + error.message });
    } finally {
      setSaving(false);
    }
  };

  const handleFooterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('認証が必要です');

      console.log('フッター設定保存開始:', footerForm);

      if (footerSettings) {
        // 更新
        console.log('フッター設定更新:', footerSettings.id);
        const { error } = await supabase
          .from('footer_settings')
          .update({
            ...footerForm,
            updated_at: new Date().toISOString()
          })
          .eq('id', footerSettings.id);

        if (error) throw error;
        console.log('フッター設定更新成功');
      } else {
        // 新規作成
        console.log('フッター設定新規作成');
        const { error } = await supabase
          .from('footer_settings')
          .insert([{
            ...footerForm,
            user_id: user.id
          }]);

        if (error) throw error;
        console.log('フッター設定作成成功');
      }

      await fetchFooterSettings();
      setMessage({ type: 'success', text: 'フッター設定を保存しました' });
    } catch (error: any) {
      console.error('フッター設定の保存に失敗しました:', error);
      setMessage({ type: 'error', text: 'フッター設定の保存に失敗しました: ' + error.message });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link
              to="/admin"
              className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">プロフィール設定</h1>
              <p className="text-gray-600 mt-2">サイトのプロフィール情報とフッター設定を管理します</p>
            </div>
          </div>
        </div>

        {/* Message */}
        {message && (
          <div className={`mb-6 p-4 rounded-xl border ${
            message.type === 'success' 
              ? 'bg-green-50 border-green-200 text-green-800' 
              : 'bg-red-50 border-red-200 text-red-800'
          }`}>
            <div className="flex items-center space-x-2">
              {message.type === 'error' && <AlertCircle className="w-5 h-5" />}
              <span>{message.text}</span>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              <button
                onClick={() => setActiveTab('profile')}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                  activeTab === 'profile'
                    ? 'text-orange-600 border-b-2 border-orange-600 bg-orange-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>プロフィール情報</span>
                </div>
              </button>
              <button
                onClick={() => setActiveTab('footer')}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                  activeTab === 'footer'
                    ? 'text-orange-600 border-b-2 border-orange-600 bg-orange-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-center space-x-2">
                  <Building className="w-5 h-5" />
                  <span>フッター設定</span>
                </div>
              </button>
            </nav>
          </div>

          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <form onSubmit={handleProfileSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    表示名 *
                  </label>
                  <input
                    type="text"
                    value={profileForm.display_name}
                    onChange={(e) => setProfileForm({ ...profileForm, display_name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                    placeholder="ブログ管理人"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ウェブサイトURL
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={profileForm.website_url}
                      onChange={(e) => setProfileForm({ ...profileForm, website_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://example.com"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  自己紹介（詳細）
                </label>
                <textarea
                  value={profileForm.bio}
                  onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                  rows={6}
                  placeholder="詳しい自己紹介を入力してください..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  自己紹介（短縮版）
                </label>
                <textarea
                  value={profileForm.short_bio}
                  onChange={(e) => setProfileForm({ ...profileForm, short_bio: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                  rows={3}
                  placeholder="サイドバーに表示される短い自己紹介..."
                />
              </div>

              <div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    アバター画像URL
                  </label>
                  <div className="relative">
                    <Image className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={profileForm.avatar_url}
                      onChange={(e) => setProfileForm({ ...profileForm, avatar_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://example.com/avatar.jpg"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Twitter URL
                  </label>
                  <div className="relative">
                    <Twitter className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={profileForm.twitter_url}
                      onChange={(e) => setProfileForm({ ...profileForm, twitter_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://twitter.com/username"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    GitHub URL
                  </label>
                  <div className="relative">
                    <Github className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={profileForm.github_url}
                      onChange={(e) => setProfileForm({ ...profileForm, github_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://github.com/username"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    LinkedIn URL
                  </label>
                  <div className="relative">
                    <Linkedin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={profileForm.linkedin_url}
                      onChange={(e) => setProfileForm({ ...profileForm, linkedin_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://linkedin.com/in/username"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ウェブサイトURL
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={profileForm.website_url}
                      onChange={(e) => setProfileForm({ ...profileForm, website_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://example.com"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  disabled={saving}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>{saving ? '保存中...' : 'プロフィールを保存'}</span>
                </button>
              </div>
            </form>
          )}

          {/* Footer Tab */}
          {activeTab === 'footer' && (
            <form onSubmit={handleFooterSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    サイト名 *
                  </label>
                  <input
                    type="text"
                    value={footerForm.company_name}
                    onChange={(e) => setFooterForm({ ...footerForm, company_name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                    placeholder="まなびログ"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    お問い合わせメール
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      value={footerForm.contact_email}
                      onChange={(e) => setFooterForm({ ...footerForm, contact_email: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="contact@example.com"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  サイト説明
                </label>
                <textarea
                  value={footerForm.company_description}
                  onChange={(e) => setFooterForm({ ...footerForm, company_description: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                  rows={4}
                  placeholder="サイトの説明文を入力してください..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    プライバシーポリシーURL
                  </label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={footerForm.privacy_policy_url}
                      onChange={(e) => setFooterForm({ ...footerForm, privacy_policy_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://example.com/privacy"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    利用規約URL
                  </label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={footerForm.terms_of_service_url}
                      onChange={(e) => setFooterForm({ ...footerForm, terms_of_service_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://example.com/terms"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    サイトマップURL
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="url"
                      value={footerForm.sitemap_url}
                      onChange={(e) => setFooterForm({ ...footerForm, sitemap_url: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                      placeholder="https://example.com/sitemap.xml"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  著作権表示
                </label>
                <input
                  type="text"
                  value={footerForm.copyright_text}
                  onChange={(e) => setFooterForm({ ...footerForm, copyright_text: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all"
                  placeholder="© 2025 まなびログ. All rights reserved."
                />
              </div>

              <div className="flex justify-end pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  disabled={saving}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>{saving ? '保存中...' : 'フッター設定を保存'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
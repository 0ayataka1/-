import React, { useState, useEffect } from 'react';
import { Search, BookOpen, Clock, Target, User, Github, Twitter, Linkedin, Calendar, Tag, ChevronRight, Coffee, Brain, Zap, X, Laptop, GraduationCap, FileText, Lightbulb, TrendingUp, Award, Users, Heart, ChefHat, Scissors, Camera, Palette, Sparkles, Star, Gift } from 'lucide-react';
import { supabase, BlogPost, Profile, FooterSettings } from '../lib/supabase';
import { Link } from 'react-router-dom';

export default function BlogHome() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [footerSettings, setFooterSettings] = useState<FooterSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    fetchPosts();
    fetchProfile();
    fetchFooterSettings();
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('published', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('記事の取得に失敗しました:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .limit(1);

      if (error) {
        console.error('プロフィールの取得に失敗しました:', error);
      } else if (data && data.length > 0) {
        setProfile(data[0]);
      } else {
        setProfile(null);
      }
    } catch (error) {
      console.error('プロフィールの取得に失敗しました:', error);
    }
  };

  const fetchFooterSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('footer_settings')
        .select('*')
        .limit(1);

      if (error) {
        console.warn('フッター設定の取得をスキップしました:', error.message);
      } else if (data && data.length > 0) {
        setFooterSettings(data[0]);
      }
    } catch (error) {
      console.warn('フッター設定の取得をスキップしました:', error);
    }
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'learning-log': return <Brain className="w-4 h-4" />;
      case 'guide': return <Camera className="w-4 h-4" />;
      case 'tools': return <Heart className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'learning-log': return '学びと効率化';
      case 'guide': return '発信と表現';
      case 'tools': return '暮らしの工夫';
      default: return category;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'learning-log': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'guide': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'tools': return 'bg-green-50 text-green-700 border-green-200';
      default: return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  const featuredPost = posts.find(post => post.featured);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md shadow-sm border-b border-orange-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 sm:h-20">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-500 via-orange-600 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                {profile?.logo_url ? (
                  <img 
                    src={profile.logo_url} 
                    alt="ロゴ"
                    className="w-5 h-5 sm:w-7 sm:h-7 object-contain"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling.style.display = 'block';
                    }}
                  />
                ) : null}
                <svg 
                  className={`w-5 h-5 sm:w-7 sm:h-7 text-white ${profile?.logo_url ? 'hidden' : 'block'}`}
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  strokeWidth="2"
                  style={{display: profile?.logo_url ? 'none' : 'block'}}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                </svg>
              </div>
              <div>
                <h1 className="text-lg sm:text-2xl font-bold text-orange-800">まなびログ</h1>
                <p className="text-xs sm:text-sm text-orange-600 font-medium hidden sm:block">挑戦する人を応援するメディア</p>
              </div>
            </div>
            
            <nav className="hidden lg:flex space-x-8">
              <a href="/" className="text-orange-700 hover:text-orange-800 transition-all duration-200 font-medium relative group">
                ホーム
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-600 transition-all duration-200 group-hover:w-full"></span>
              </a>
              <a href="#" className="text-orange-700 hover:text-orange-800 transition-all duration-200 font-medium relative group">
                学びと効率化
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-600 transition-all duration-200 group-hover:w-full"></span>
              </a>
              <a href="#" className="text-orange-700 hover:text-orange-800 transition-all duration-200 font-medium relative group">
                発信と表現
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-600 transition-all duration-200 group-hover:w-full"></span>
              </a>
              <a href="#" className="text-orange-700 hover:text-orange-800 transition-all duration-200 font-medium relative group">
                暮らしの工夫
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-600 transition-all duration-200 group-hover:w-full"></span>
              </a>
              <Link to="/profile" className="text-orange-700 hover:text-orange-800 transition-all duration-200 font-medium relative group">
                プロフィール
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-600 transition-all duration-200 group-hover:w-full"></span>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-12">
        {/* Hero Section */}
        <section className="relative overflow-hidden rounded-3xl mb-16">
          <div className="absolute inset-0 bg-gradient-to-br from-orange-800 via-red-800 to-amber-800"></div>
          <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=1200')] bg-cover bg-center opacity-30"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30"></div>
          
          <div className="relative px-4 sm:px-8 py-12 sm:py-20 lg:py-28">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="text-white">
                <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6 leading-tight">
                  <span className="block text-white mb-4">
                    時間をつくって、
                  </span>
                  <span className="block text-transparent bg-gradient-to-r from-orange-300 to-yellow-300 bg-clip-text">
                  </span>
                  <span className="block text-transparent bg-gradient-to-r from-orange-200 via-yellow-300 to-amber-400 bg-clip-text font-extrabold drop-shadow-lg">
                    学びを広げる。
                  </span>
                </h1>
                <p className="text-base sm:text-xl mb-6 sm:mb-8 text-orange-100 leading-relaxed max-w-2xl">
                  暮らしの工夫からツール活用まで。
                  <br />
                  <span className="relative inline-block">
                    <span className="relative z-10 font-bold text-white">挑戦を続けたい人</span>
                    <span className="absolute bottom-1 left-0 w-full h-3 bg-gradient-to-r from-yellow-300 to-amber-300 opacity-60 rounded-sm transform -skew-x-12"></span>
                  </span>のための
                  <span className="font-bold text-yellow-200">"学び直しメディア"</span>
                </p>
                
                <div className="flex flex-wrap gap-2 sm:gap-4 mb-6 sm:mb-8">
                  <div className="flex items-center space-x-2 sm:space-x-3 bg-white/20 backdrop-blur-sm rounded-xl px-3 sm:px-6 py-2 sm:py-3 border border-white/30">
                    <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                    <span className="font-medium text-sm sm:text-base">学びと効率化</span>
                  </div>
                  <div className="flex items-center space-x-2 sm:space-x-3 bg-white/20 backdrop-blur-sm rounded-xl px-3 sm:px-6 py-2 sm:py-3 border border-white/30">
                    <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400" />
                    <span className="font-medium text-sm sm:text-base">発信と表現</span>
                  </div>
                  <div className="flex items-center space-x-2 sm:space-x-3 bg-white/20 backdrop-blur-sm rounded-xl px-3 sm:px-6 py-2 sm:py-3 border border-white/30">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                    <span className="font-medium text-sm sm:text-base">暮らしの工夫</span>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  {posts.length > 0 && (
                    <Link
                      to={`/post/${posts[0].id}`}
                      className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 text-center text-sm sm:text-base"
                    >
                      最新記事を読む
                    </Link>
                  )}
                  <button className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold transition-all duration-200 border border-white/30 text-sm sm:text-base">
                    記事一覧を見る
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 lg:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Featured Post */}
            {featuredPost && (
              <section className="mb-12 sm:mb-16">
                <div className="flex items-center space-x-3 mb-6 sm:mb-8">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-orange-400 to-red-500 rounded-lg flex items-center justify-center">
                    <Star className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <h2 className="text-xl sm:text-3xl font-bold text-gray-900">注目記事</h2>
                </div>
                
                <article className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group">
                  <div className="relative h-48 sm:h-64 overflow-hidden">
                    <img 
                      src={featuredPost.image_url || 'https://images.pexels.com/photos/1226398/pexels-photo-1226398.jpeg?auto=compress&cs=tinysrgb&w=800'} 
                      alt={featuredPost.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                    <div className="absolute top-3 left-3 sm:top-4 sm:left-4">
                      <span className={`inline-flex items-center space-x-1 sm:space-x-2 px-2 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-semibold border backdrop-blur-sm ${getCategoryColor(featuredPost.category)} bg-white/90`}>
                        {getCategoryIcon(featuredPost.category)}
                        <span>{getCategoryName(featuredPost.category)}</span>
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-4 sm:p-8">
                    <div className="flex items-center space-x-2 sm:space-x-4 mb-3 sm:mb-4 text-xs sm:text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                        <span>{new Date(featuredPost.created_at).toLocaleDateString('ja-JP')}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                        <span>{featuredPost.read_time}</span>
                      </div>
                    </div>
                    
                    <h3 className="text-lg sm:text-2xl font-bold text-gray-900 mb-3 sm:mb-4 hover:text-orange-600 transition-colors cursor-pointer group-hover:text-orange-600 leading-tight">
                      <Link to={`/post/${featuredPost.id}`}>{featuredPost.title}</Link>
                    </h3>
                    
                    <p className="text-gray-700 leading-relaxed mb-4 sm:mb-6 text-sm sm:text-lg">
                      {featuredPost.excerpt}
                    </p>
                    
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="flex flex-wrap gap-2">
                        {featuredPost.tags.map((tag, index) => (
                          <span key={index} className="inline-flex items-center space-x-1 text-xs sm:text-sm font-medium text-gray-600 bg-gray-100 rounded-full px-3 sm:px-4 py-1 sm:py-2 hover:bg-gray-200 transition-colors cursor-pointer">
                            <Tag className="w-2 h-2 sm:w-3 sm:h-3" />
                            <span>{tag}</span>
                          </span>
                        ))}
                      </div>
                      <Link
                        to={`/post/${featuredPost.id}`}
                        className="inline-flex items-center justify-center space-x-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold px-4 sm:px-6 py-2 sm:py-3 rounded-xl transition-all duration-200 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 text-sm sm:text-base"
                      >
                        <span>続きを読む</span>
                        <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                      </Link>
                    </div>
                  </div>
                </article>
              </section>
            )}

            {/* Search and Filter */}
            <section className="mb-8 sm:mb-12">
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 sm:left-4 top-3 sm:top-4 w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="記事を検索..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 sm:pl-12 pr-3 sm:pr-4 py-3 sm:py-4 border border-orange-200 rounded-2xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all bg-white shadow-sm hover:shadow-md text-sm sm:text-base"
                  />
                </div>
                
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-4 sm:px-6 py-3 sm:py-4 border border-orange-200 rounded-2xl focus:ring-2 focus:ring-orange-400 focus:border-transparent outline-none transition-all bg-white shadow-sm hover:shadow-md font-medium text-sm sm:text-base"
                >
                  <option value="all">全カテゴリー</option>
                  <option value="learning-log">学びと効率化</option>
                  <option value="guide">発信と表現</option>
                  <option value="tools">暮らしの工夫</option>
                </select>
              </div>
            </section>

            {/* Blog Posts */}
            <section>
              <div className="flex items-center space-x-3 mb-6 sm:mb-8">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                  <Gift className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <h2 className="text-xl sm:text-3xl font-bold text-gray-900">最新記事</h2>
                <span className="text-sm sm:text-lg text-gray-600 font-medium">({filteredPosts.length}件)</span>
              </div>
              
              <div className="grid gap-6 sm:gap-8">
                {filteredPosts.map((post) => (
                  <article
                    key={post.id}
                    className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-0">
                      <div className="relative h-48 sm:h-full overflow-hidden">
                        <img 
                          src={post.image_url || 'https://images.pexels.com/photos/1226398/pexels-photo-1226398.jpeg?auto=compress&cs=tinysrgb&w=800'} 
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/20"></div>
                      </div>
                      
                      <div className="sm:col-span-2 p-4 sm:p-8">
                        <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-3 sm:mb-4">
                          <span className={`inline-flex items-center space-x-1 sm:space-x-2 px-2 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-semibold border ${getCategoryColor(post.category)} w-fit`}>
                            {getCategoryIcon(post.category)}
                            <span>{getCategoryName(post.category)}</span>
                          </span>
                          <div className="flex items-center space-x-2 sm:space-x-4 text-xs sm:text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                              <span>{new Date(post.created_at).toLocaleDateString('ja-JP')}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                              <span>{post.read_time}</span>
                            </div>
                          </div>
                        </div>
                        
                        <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 hover:text-orange-600 transition-colors cursor-pointer group-hover:text-orange-600 leading-tight">
                          <Link to={`/post/${post.id}`}>{post.title}</Link>
                        </h3>
                        
                        <p className="text-gray-700 leading-relaxed mb-4 sm:mb-6 text-sm sm:text-base">
                          {post.excerpt}
                        </p>
                        
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0">
                          <div className="flex flex-wrap gap-2">
                            {post.tags.slice(0, 3).map((tag, index) => (
                              <span key={index} className="inline-flex items-center space-x-1 text-xs sm:text-sm font-medium text-gray-600 bg-gray-100 rounded-full px-2 sm:px-3 py-1 hover:bg-gray-200 transition-colors cursor-pointer">
                                <Tag className="w-2 h-2 sm:w-3 sm:h-3" />
                                <span>{tag}</span>
                              </span>
                            ))}
                            {post.tags.length > 3 && (
                              <span className="text-xs sm:text-sm text-gray-500 font-medium">+{post.tags.length - 3}</span>
                            )}
                          </div>
                          <Link
                            to={`/post/${post.id}`}
                            className="inline-flex items-center justify-center space-x-2 text-orange-600 font-semibold hover:text-orange-700 transition-colors text-sm sm:text-base"
                          >
                            <span>続きを読む</span>
                            <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                          </Link>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
              
              {filteredPosts.length === 0 && (
                <div className="text-center py-12 sm:py-16">
                  <div className="w-16 h-16 sm:w-24 sm:h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                    <Search className="w-8 h-8 sm:w-12 sm:h-12 text-gray-400" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3">記事が見つかりませんでした</h3>
                  <p className="text-gray-600 text-sm sm:text-base">別のキーワードやカテゴリーで検索してみてください。</p>
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6 sm:space-y-8">
            {/* Profile */}
            <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-4 sm:p-8">
              <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                  <User className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900">プロフィール</h3>
              </div>
              
              <div className="text-center mb-6 sm:mb-8">
                {profile?.avatar_url ? (
                  <img 
                    src={profile.avatar_url} 
                    alt={profile.display_name || 'ブログ管理人'}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl mx-auto mb-3 sm:mb-4 object-cover shadow-lg border-2 border-white"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling.style.display = 'flex';
                    }}
                  />
                ) : null}
                {!profile?.avatar_url && (
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl mx-auto mb-3 sm:mb-4 flex items-center justify-center shadow-lg">
                    <User className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                  </div>
                )}
                {profile?.avatar_url && (
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl mx-auto mb-3 sm:mb-4 flex items-center justify-center shadow-lg" style={{display: 'none'}}>
                    <User className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                  </div>
                )}
                <p className="text-gray-700 leading-relaxed text-sm sm:text-base mb-4 sm:mb-6">
                  {profile?.short_bio || '30代サラリーマン。働きながらの学び直しを実践中。プログラミング、英語学習、資格取得など幅広く挑戦しています。'}
                </p>
              </div>
              
              <div className="flex justify-center space-x-3 sm:space-x-4">
                {profile?.twitter_url && (
                  <a href={profile.twitter_url} target="_blank" rel="noopener noreferrer" className="p-2 sm:p-3 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-xl">
                    <X className="w-4 h-4 sm:w-5 sm:h-5" />
                  </a>
                )}
                {profile?.github_url && (
                  <a href={profile.github_url} target="_blank" rel="noopener noreferrer" className="p-2 sm:p-3 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-xl">
                    <Github className="w-4 h-4 sm:w-5 sm:h-5" />
                  </a>
                )}
                {/* デフォルトのソーシャルリンクを表示（プロフィールが設定されていない場合） */}
                {!profile && (
                  <>
                    <div className="p-2 sm:p-3 text-gray-400 bg-orange-50 rounded-xl cursor-not-allowed">
                      <X className="w-4 h-4 sm:w-5 sm:h-5" />
                    </div>
                    <div className="p-2 sm:p-3 text-gray-400 bg-orange-50 rounded-xl cursor-not-allowed">
                      <Github className="w-4 h-4 sm:w-5 sm:h-5" />
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Popular Tags */}
            <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-4 sm:p-8">
              <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-amber-500 to-orange-500 rounded-lg flex items-center justify-center">
                  <Tag className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900">人気タグ</h3>
              </div>
              
              <div className="flex flex-wrap gap-2 sm:gap-3">
                {['学び', '効率化', '挑戦'].map((tag) => (
                  <span
                    key={tag}
                    className="inline-block px-3 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm font-semibold text-orange-700 bg-orange-100 rounded-xl hover:bg-orange-200 hover:text-orange-800 transition-all duration-200 cursor-pointer transform hover:-translate-y-0.5"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-4 sm:p-8">
              <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                  <Award className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900">ブログ統計</h3>
              </div>
              
              <div className="space-y-3 sm:space-y-6">
                <div className="flex justify-between items-center p-3 sm:p-4 bg-gray-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <Gift className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                    <span className="text-gray-700 font-medium text-sm sm:text-base">総記事数</span>
                  </div>
                  <span className="font-bold text-gray-900 text-base sm:text-lg">{posts.length}</span>
                </div>
                <div className="flex justify-between items-center p-3 sm:p-4 bg-blue-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
                    <span className="text-blue-700 font-medium text-sm sm:text-base">学びと効率化</span>
                  </div>
                  <span className="font-bold text-blue-700 text-base sm:text-lg">{posts.filter(p => p.category === 'learning-log').length}</span>
                </div>
                <div className="flex justify-between items-center p-3 sm:p-4 bg-orange-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-orange-600" />
                    <span className="text-orange-700 font-medium text-sm sm:text-base">発信と表現</span>
                  </div>
                  <span className="font-bold text-orange-700 text-base sm:text-lg">{posts.filter(p => p.category === 'guide').length}</span>
                </div>
                <div className="flex justify-between items-center p-3 sm:p-4 bg-green-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
                    <span className="text-green-700 font-medium text-sm sm:text-base">暮らしの工夫</span>
                  </div>
                  <span className="font-bold text-green-700 text-base sm:text-lg">{posts.filter(p => p.category === 'tools').length}</span>
                </div>
              </div>
            </div>

            {/* Community */}
            <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-3xl shadow-lg p-4 sm:p-8 text-white">
              <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-white/25 rounded-lg flex items-center justify-center">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold">コミュニティ準備中</h3>
              </div>
              
              <p className="text-base sm:text-lg mb-6 sm:mb-8 text-orange-100 leading-relaxed max-w-2xl">
                暮らしの工夫からツール活用まで。<span className="relative inline-block">
                  <span className="relative z-10 font-bold text-white">挑戦を続けたい人</span>
                  <span className="absolute bottom-1 left-0 w-full h-3 bg-gradient-to-r from-yellow-300 to-amber-300 opacity-60 rounded-sm transform -skew-x-12"></span>
                </span>のための
                <span className="font-bold text-yellow-200">"学び直しメディア"</span>
              </p>
              
              <button className="w-full bg-white/25 hover:bg-white/35 backdrop-blur-sm text-white font-semibold px-4 sm:px-6 py-2 sm:py-3 rounded-xl transition-all duration-200 border border-white/40 text-sm sm:text-base">
                コミュニティに参加
              </button>
            </div>
          </aside>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-orange-900 via-red-900 to-amber-900 text-white mt-12 sm:mt-20">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 sm:space-x-4 mb-4 sm:mb-6">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-500 via-orange-600 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                  {profile?.logo_url ? (
                    <img 
                      src={profile.logo_url} 
                      alt="ロゴ"
                      className="w-5 h-5 sm:w-7 sm:h-7 object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling.style.display = 'block';
                      }}
                    />
                  ) : null}
                  <svg 
                    className={`w-5 h-5 sm:w-7 sm:h-7 text-white ${profile?.logo_url ? 'hidden' : 'block'}`}
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    strokeWidth="2"
                    style={{display: profile?.logo_url ? 'none' : 'block'}}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                  </svg>
                </div>
                <div>
                  <h1 className="text-lg sm:text-2xl font-bold text-white">まなびログ</h1>
                  <p className="text-xs sm:text-sm text-orange-200 font-medium">挑戦する人を応援するメディア</p>
                </div>
              </div>
              <p className="text-orange-200 leading-relaxed mb-4 sm:mb-6 max-w-md text-sm sm:text-base">
                {footerSettings?.company_description || '忙しい人こそ取り入れてほしい効率化ツールなどを紹介。選択肢を増やし、常に挑戦し続ける人を応援します。'}
              </p>
              <div className="flex space-x-3 sm:space-x-4">
                {profile?.twitter_url ? (
                  <a href={profile.twitter_url} target="_blank" rel="noopener noreferrer" className="p-2 sm:p-3 text-orange-300 hover:text-white transition-colors bg-orange-800 hover:bg-orange-700 rounded-xl">
                    <X className="w-4 h-4 sm:w-5 sm:h-5" />
                  </a>
                ) : (
                  <div className="p-2 sm:p-3 text-orange-400 bg-orange-800 rounded-xl cursor-not-allowed">
                    <X className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                )}
                {profile?.github_url ? (
                  <a href={profile.github_url} target="_blank" rel="noopener noreferrer" className="p-2 sm:p-3 text-orange-300 hover:text-white transition-colors bg-orange-800 hover:bg-orange-700 rounded-xl">
                    <Github className="w-4 h-4 sm:w-5 sm:h-5" />
                  </a>
                ) : (
                  <div className="p-2 sm:p-3 text-orange-400 bg-orange-800 rounded-xl cursor-not-allowed">
                    <Github className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h3 className="font-bold mb-4 sm:mb-6 text-base sm:text-lg">カテゴリー</h3>
              <ul className="space-y-2 sm:space-y-3">
                <li><a href="/" className="text-orange-200 hover:text-white transition-colors flex items-center space-x-2">
                  <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                  </svg>
                  <span className="text-sm sm:text-base">ホーム</span>
                </a></li>
                <li><a href="#" className="text-orange-200 hover:text-white transition-colors flex items-center space-x-2">
                  <Brain className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="text-sm sm:text-base">学びと効率化</span>
                </a></li>
                <li><a href="#" className="text-orange-200 hover:text-white transition-colors flex items-center space-x-2">
                  <Camera className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="text-sm sm:text-base">発信と表現</span>
                </a></li>
                <li><a href="#" className="text-orange-200 hover:text-white transition-colors flex items-center space-x-2">
                  <Heart className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="text-sm sm:text-base">暮らしの工夫</span>
                </a></li>
                <li><Link to="/profile" className="text-orange-200 hover:text-white transition-colors flex items-center space-x-2">
                  <User className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="text-sm sm:text-base">プロフィール</span>
                </Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-4 sm:mb-6 text-base sm:text-lg">サポート</h3>
              <ul className="space-y-2 sm:space-y-3">
                <li>
                  {footerSettings?.contact_email ? (
                    <a href={`mailto:${footerSettings.contact_email}`} className="text-orange-200 hover:text-white transition-colors text-sm sm:text-base">お問い合わせ</a>
                  ) : (
                    <span className="text-orange-400 cursor-not-allowed text-sm sm:text-base">お問い合わせ</span>
                  )}
                </li>
                <li>
                  <a href={footerSettings?.privacy_policy_url || '#'} className={`transition-colors text-sm sm:text-base ${footerSettings?.privacy_policy_url && footerSettings.privacy_policy_url !== '#' ? 'text-orange-200 hover:text-white' : 'text-orange-400 cursor-not-allowed'}`}>
                    プライバシーポリシー
                  </a>
                </li>
                <li>
                  <a href="#" className="text-orange-200 hover:text-white transition-colors text-sm sm:text-base">
                    サイトマップ
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-orange-800 mt-8 sm:mt-12 pt-6 sm:pt-8">
            <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
              <span className="block text-transparent bg-gradient-to-r from-orange-300 to-yellow-300 bg-clip-text">
                時間をつくって、学びを広げる。
              </span>
              <p className="text-base sm:text-xl mb-6 sm:mb-8 text-orange-100 leading-relaxed max-w-2xl">
                暮らしの工夫からツール活用まで。
                <br />
                <span className="relative inline-block">
                  <span className="relative z-10 font-bold text-white">挑戦を続けたい人</span>
                  <span className="absolute bottom-1 left-0 w-full h-3 bg-gradient-to-r from-yellow-300 to-amber-300 opacity-60 rounded-sm transform -skew-x-12"></span>
                </span>のための
                <span className="font-bold text-yellow-200">"学び直しメディア"</span>
              </p>
              <div className="flex items-center space-x-2 text-orange-200 text-xs sm:text-sm">
                <Heart className="w-3 h-3 sm:w-4 sm:h-4 text-red-500" />
                <span>Made with love for creators</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
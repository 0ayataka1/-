import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase, BlogPost as BlogPostType, Profile } from '../lib/supabase';
import { Calendar, Clock, Tag, ChevronLeft, User, Github, X, Brain, Camera, Heart } from 'lucide-react';

export default function BlogPost() {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<BlogPostType | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchPost(id);
      fetchProfile();
    }
  }, [id]);

  const fetchPost = async (postId: string) => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('id', postId)
        .eq('published', true)
        .single();

      if (error) throw error;
      setPost(data);
    } catch (error) {
      console.error('記事の取得に失敗しました:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .limit(1);

      if (error) {
        console.error('プロフィールの取得に失敗しました:', error);
      } else if (data && data.length > 0) {
        setProfile(data[0]);
      }
    } catch (error) {
      console.error('プロフィールの取得に失敗しました:', error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'learning-log': return <Brain className="w-4 h-4" />;
      case 'guide': return <Camera className="w-4 h-4" />;
      case 'tools': return <Heart className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'learning-log': return '学びと効率化';
      case 'guide': return '発信と表現';
      case 'tools': return '暮らしの工夫';
      default: return category;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'learning-log': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'guide': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'tools': return 'bg-green-50 text-green-700 border-green-200';
      default: return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">記事が見つかりません</h1>
          <p className="text-gray-600 mb-8">指定された記事は存在しないか、公開されていません。</p>
          <Link
            to="/"
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            ホームに戻る
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md shadow-sm border-b border-orange-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 sm:h-20">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-500 via-orange-600 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                {profile?.logo_url ? (
                  <img 
                    src={profile.logo_url} 
                    alt="ロゴ"
                    className="w-5 h-5 sm:w-7 sm:h-7 object-contain"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling.style.display = 'block';
                    }}
                  />
                ) : null}
                <svg 
                  className={`w-5 h-5 sm:w-7 sm:h-7 text-white ${profile?.logo_url ? 'hidden' : 'block'}`}
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  strokeWidth="2"
                  style={{display: profile?.logo_url ? 'none' : 'block'}}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                </svg>
              </div>
              <div>
                <Link to="/" className="text-lg sm:text-2xl font-bold text-orange-800 hover:text-orange-900 transition-colors">
                  まなびログ
                </Link>
                <p className="text-xs sm:text-sm text-orange-600 font-medium hidden sm:block">挑戦する人を応援するメディア</p>
              </div>
            </div>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-orange-700 hover:text-orange-800 transition-colors font-medium"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">ホームに戻る</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Article Header */}
        <article className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden mb-8">
          {post.image_url && (
            <div className="relative h-64 sm:h-80 lg:h-96 overflow-hidden">
              <img 
                src={post.image_url} 
                alt={post.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
              <div className="absolute bottom-6 left-6">
                <span className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-semibold border backdrop-blur-sm ${getCategoryColor(post.category)} bg-white/90`}>
                  {getCategoryIcon(post.category)}
                  <span>{getCategoryName(post.category)}</span>
                </span>
              </div>
            </div>
          )}
          
          <div className="p-6 sm:p-8 lg:p-12">
            {!post.image_url && (
              <div className="mb-6">
                <span className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-semibold border ${getCategoryColor(post.category)}`}>
                  {getCategoryIcon(post.category)}
                  <span>{getCategoryName(post.category)}</span>
                </span>
              </div>
            )}
            
            <div className="flex items-center space-x-4 mb-6 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>{new Date(post.created_at).toLocaleDateString('ja-JP', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>{post.read_time}</span>
              </div>
            </div>
            
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-6 leading-tight">
              {post.title}
            </h1>
            
            <p className="text-lg text-gray-700 leading-relaxed mb-8">
              {post.excerpt}
            </p>
            
            {post.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-8">
                {post.tags.map((tag, index) => (
                  <span key={index} className="inline-flex items-center space-x-1 text-sm font-medium text-gray-600 bg-gray-100 rounded-full px-4 py-2 hover:bg-gray-200 transition-colors">
                    <Tag className="w-3 h-3" />
                    <span>{tag}</span>
                  </span>
                ))}
              </div>
            )}
          </div>
        </article>

        {/* Article Content */}
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-6 sm:p-8 lg:p-12 mb-8">
          <div 
            className="rich-content prose prose-lg max-w-none"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </div>

        {/* Author Info */}
        {profile && (
          <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-6 sm:p-8">
            <div className="flex items-start space-x-4">
              {profile.avatar_url ? (
                <img 
                  src={profile.avatar_url} 
                  alt={profile.display_name}
                  className="w-16 h-16 rounded-2xl object-cover shadow-lg border-2 border-white"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling.style.display = 'flex';
                  }}
                />
              ) : null}
              {!profile.avatar_url && (
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                  <User className="w-8 h-8 text-white" />
                </div>
              )}
              {profile.avatar_url && (
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl items-center justify-center shadow-lg" style={{display: 'none'}}>
                  <User className="w-8 h-8 text-white" />
                </div>
              )}
              
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {profile.display_name || 'あやたか'}
                </h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  {profile.short_bio || `私は「小さい頃から“どうして？”と考えるクセがあり、調べて勉強するのが得意でした📚
学生の頃は管理栄養士を目指すも、進む道に悩み…。社会人を経験して、食品業界→IT業界へ転身！
時に間違えながらも、チャレンジを繰り返す20代を送りました。

このブログは、そんな私自身の「学び直しの記録」です。
同じように「もう一度学んでみたい」「新しいことに挑戦したい」と思っている方に
共感できること、ちょっとしたヒントになるようなことをお伝えできたら嬉しいです。`}
                </p>
                
                <div className="flex space-x-3">
                  {profile.twitter_url && (
                    <a 
                      href={profile.twitter_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-2 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-lg"
                    >
                      <X className="w-5 h-5" />
                    </a>
                  )}
                  {profile.github_url && (
                    <a 
                      href={profile.github_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-2 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-lg"
                    >
                      <Github className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Back to Home */}
        <div className="text-center mt-12">
          <Link
            to="/"
            className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            <ChevronLeft className="w-5 h-5" />
            <span>他の記事を読む</span>
          </Link>
        </div>
      </main>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase, Profile } from '../lib/supabase';
import { User, Github, Twitter, Linkedin, ChevronLeft, Mail, Globe, MapPin, Calendar, Heart, Award, Coffee, Sparkles } from 'lucide-react';

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .limit(1);

      if (error) {
        console.error('プロフィールの取得に失敗しました:', error);
      } else if (data && data.length > 0) {
        setProfile(data[0]);
      }
    } catch (error) {
      console.error('プロフィールの取得に失敗しました:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md shadow-sm border-b border-orange-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 sm:h-20">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-500 via-orange-600 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                {profile?.logo_url ? (
                  <img 
                    src={profile.logo_url} 
                    alt="ロゴ"
                    className="w-5 h-5 sm:w-7 sm:h-7 object-contain"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling.style.display = 'block';
                    }}
                  />
                ) : null}
                <svg 
                  className={`w-5 h-5 sm:w-7 sm:h-7 text-white ${profile?.logo_url ? 'hidden' : 'block'}`}
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  strokeWidth="2"
                  style={{display: profile?.logo_url ? 'none' : 'block'}}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                </svg>
              </div>
              <div>
                <Link to="/" className="text-lg sm:text-2xl font-bold text-orange-800 hover:text-orange-900 transition-colors">
                  まなびログ
                </Link>
                <p className="text-xs sm:text-sm text-orange-600 font-medium hidden sm:block">挑戦する人を応援するメディア</p>
              </div>
            </div>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-orange-700 hover:text-orange-800 transition-colors font-medium"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">ホームに戻る</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Hero */}
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden mb-8">
          <div className="relative h-32 sm:h-48 bg-gradient-to-r from-orange-500 via-red-500 to-amber-500">
            <div className="absolute inset-0 bg-black/20"></div>
          </div>
          
          <div className="relative px-6 sm:px-8 pb-8">
            <div className="flex flex-col sm:flex-row sm:items-end sm:space-x-6 -mt-16 sm:-mt-20">
              <div className="relative">
                {profile?.avatar_url ? (
                  <img 
                    src={profile.avatar_url} 
                    alt={profile.display_name || 'プロフィール'}
                    className="w-24 h-24 sm:w-32 sm:h-32 rounded-3xl object-cover shadow-lg border-4 border-white mx-auto sm:mx-0"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling.style.display = 'flex';
                    }}
                  />
                ) : null}
                {!profile?.avatar_url && (
                  <div className="w-24 h-24 sm:w-32 sm:h-32 bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl flex items-center justify-center shadow-lg border-4 border-white mx-auto sm:mx-0">
                    <User className="w-12 h-12 sm:w-16 sm:h-16 text-white" />
                  </div>
                )}
                {profile?.avatar_url && (
                  <div className="w-24 h-24 sm:w-32 sm:h-32 bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl flex items-center justify-center shadow-lg border-4 border-white mx-auto sm:mx-0" style={{display: 'none'}}>
                    <User className="w-12 h-12 sm:w-16 sm:h-16 text-white" />
                  </div>
                )}
              </div>
              
              <div className="flex-1 text-center sm:text-left mt-4 sm:mt-0 sm:pb-4">
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                  {profile?.display_name || 'あやたか'}
                </h1>
                
                <div className="flex justify-center sm:justify-start space-x-4">
                  {profile?.twitter_url && (
                    <a 
                      href={profile.twitter_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-3 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-xl"
                    >
                      <Twitter className="w-5 h-5" />
                    </a>
                  )}
                  {profile?.github_url && (
                    <a 
                      href={profile.github_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-3 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-xl"
                    >
                      <Github className="w-5 h-5" />
                    </a>
                  )}
                  {profile?.linkedin_url && (
                    <a 
                      href={profile.linkedin_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-3 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-xl"
                    >
                      <Linkedin className="w-5 h-5" />
                    </a>
                  )}
                  {profile?.website_url && (
                    <a 
                      href={profile.website_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="p-3 text-gray-600 hover:text-orange-600 transition-colors bg-orange-50 hover:bg-orange-100 rounded-xl"
                    >
                      <Globe className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-6 sm:p-8 mb-8">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">自己紹介</h2>
          </div>
          
          <div className="prose prose-lg max-w-none">
            <div className="text-gray-700 leading-relaxed text-lg mb-6 whitespace-pre-line">
              {profile?.bio || `私は「小さい頃から“どうして？”と考えるクセがあり、調べて勉強するのが得意でした📚
学生の頃は管理栄養士を目指すも、進む道に悩み…。社会人を経験して、食品業界→IT業界へ転身！
時に間違えながらも、チャレンジを繰り返す20代を送りました。`}
            </div>
          </div>
        </div>

        {/* Skills & Interests */}

        {/* Contact */}
        <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-3xl shadow-lg p-6 sm:p-8 text-white text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-white/25 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-xl font-bold">お気軽にご連絡ください</h3>
          </div>
          
          <p className="text-orange-100 mb-6 leading-relaxed">
            コラボレーションのご相談や、ブログに関するご質問など、<br className="hidden sm:block" />
            お気軽にお声がけください。
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white/25 hover:bg-white/35 backdrop-blur-sm text-white font-semibold px-6 py-3 rounded-xl transition-all duration-200 border border-white/40">
              お問い合わせ
            </button>
            <Link
              to="/"
              className="bg-white/25 hover:bg-white/35 backdrop-blur-sm text-white font-semibold px-6 py-3 rounded-xl transition-all duration-200 border border-white/40 text-center"
            >
              ブログを読む
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}

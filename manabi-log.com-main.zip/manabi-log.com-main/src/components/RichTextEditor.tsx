import React from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import 'quill-better-table/dist/quill-better-table.css';

// Quill Better Table のインポート
import QuillBetterTable from 'quill-better-table';

// Quillにモジュールを登録
if (typeof window !== 'undefined') {
  const Quill = ReactQuill.Quill;
  Quill.register('modules/better-table', QuillBetterTable);
}

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  height?: string;
}

export default function RichTextEditor({ 
  value, 
  onChange, 
  placeholder = "記事の内容を入力してください...",
  height = "400px"
}: RichTextEditorProps) {
  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      [{ 'font': [] }],
      [{ 'size': ['small', false, 'large', 'huge'] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'script': 'sub'}, { 'script': 'super' }],
      ['blockquote', 'code-block'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'indent': '-1'}, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }],
      [{ 'align': [] }],
      ['link', 'image', 'video'],
      ['better-table'],
      ['clean']
    ],
    'better-table': {
      operationMenu: {
        items: {
          unmergeCells: {
            text: 'セルの結合を解除'
          },
          insertColumnRight: {
            text: '右に列を挿入'
          },
          insertColumnLeft: {
            text: '左に列を挿入'
          },
          insertRowUp: {
            text: '上に行を挿入'
          },
          insertRowDown: {
            text: '下に行を挿入'
          },
          mergeCells: {
            text: 'セルを結合'
          },
          deleteColumn: {
            text: '列を削除'
          },
          deleteRow: {
            text: '行を削除'
          },
          deleteTable: {
            text: '表を削除'
          }
        }
      }
    },
    clipboard: {
      matchVisual: false,
    }
  };

  const formats = [
    'header', 'font', 'size',
    'bold', 'italic', 'underline', 'strike',
    'color', 'background',
    'script',
    'blockquote', 'code-block',
    'list', 'bullet',
    'indent',
    'direction', 'align',
    'link', 'image', 'video',
    'better-table'
  ];

  return (
    <div className="rich-text-editor">
      <style jsx global>{`
        .ql-editor {
          min-height: ${height};
          font-size: 16px;
          line-height: 1.6;
        }
        
        .ql-toolbar {
          border-top: 1px solid #e5e7eb;
          border-left: 1px solid #e5e7eb;
          border-right: 1px solid #e5e7eb;
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f9fafb;
        }
        
        .ql-container {
          border-bottom: 1px solid #e5e7eb;
          border-left: 1px solid #e5e7eb;
          border-right: 1px solid #e5e7eb;
          border-top: none;
          border-radius: 0 0 12px 12px;
          background: white;
        }
        
        .ql-toolbar .ql-stroke {
          fill: none;
          stroke: #374151;
        }
        
        .ql-toolbar .ql-fill {
          fill: #374151;
          stroke: none;
        }
        
        .ql-toolbar .ql-picker-label {
          color: #374151;
        }
        
        .ql-toolbar button:hover,
        .ql-toolbar button:focus {
          color: #2563eb;
        }
        
        .ql-toolbar button:hover .ql-stroke {
          stroke: #2563eb;
        }
        
        .ql-toolbar button:hover .ql-fill {
          fill: #2563eb;
        }
        
        .ql-toolbar .ql-active {
          color: #2563eb;
        }
        
        .ql-toolbar .ql-active .ql-stroke {
          stroke: #2563eb;
        }
        
        .ql-toolbar .ql-active .ql-fill {
          fill: #2563eb;
        }
        
        .ql-editor.ql-blank::before {
          color: #9ca3af;
          font-style: normal;
        }
        
        .ql-editor h1 {
          font-size: 2.25rem;
          font-weight: 700;
          margin-bottom: 1rem;
          margin-top: 1.5rem;
        }
        
        .ql-editor h2 {
          font-size: 1.875rem;
          font-weight: 700;
          margin-bottom: 0.75rem;
          margin-top: 1.25rem;
        }
        
        .ql-editor h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
          margin-top: 1rem;
        }
        
        .ql-editor p {
          margin-bottom: 1rem;
        }
        
        .ql-editor ul, .ql-editor ol {
          margin-bottom: 1rem;
        }
        
        .ql-editor blockquote {
          border-left: 4px solid #3b82f6;
          background: #eff6ff;
          padding: 1rem;
          margin: 1rem 0;
          border-radius: 0 8px 8px 0;
        }
        
        .ql-editor code {
          background: #f3f4f6;
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
        }
        
        .ql-editor pre {
          background: #1f2937;
          color: #f9fafb;
          padding: 1rem;
          border-radius: 8px;
          overflow-x: auto;
          margin: 1rem 0;
        }
        
        .ql-editor pre code {
          background: transparent;
          color: inherit;
          padding: 0;
        }
        
        /* 表のスタイル */
        .ql-editor table {
          border-collapse: collapse;
          width: 100%;
          margin: 1rem 0;
          border: 1px solid #e5e7eb;
        }
        
        .ql-editor table td,
        .ql-editor table th {
          border: 1px solid #e5e7eb;
          padding: 0.75rem;
          text-align: left;
          vertical-align: top;
        }
        
        .ql-editor table th {
          background-color: #f9fafb;
          font-weight: 600;
          color: #374151;
        }
        
        .ql-editor table tr:nth-child(even) {
          background-color: #f9fafb;
        }
        
        .ql-editor table tr:hover {
          background-color: #f3f4f6;
        }
        
        /* Better Table のスタイル調整 */
        .qlbt-operation-menu {
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
          z-index: 1000;
        }
        
        .qlbt-operation-menu-item {
          padding: 0.5rem 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        
        .qlbt-operation-menu-item:hover {
          background-color: #f3f4f6;
        }
        
        .qlbt-col-tool,
        .qlbt-row-tool {
          background: #3b82f6;
          border-radius: 4px;
        }
        
        .qlbt-col-tool:hover,
        .qlbt-row-tool:hover {
          background: #2563eb;
        }
      `}</style>
      
      <ReactQuill
        theme="snow"
        value={value}
        onChange={onChange}
        modules={modules}
        formats={formats}
        placeholder={placeholder}
      />
    </div>
  );
}
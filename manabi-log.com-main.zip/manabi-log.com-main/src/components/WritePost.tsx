import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Search, BookOpen, Clock, Target, User, Github, Twitter, Linkedin, Calendar, Tag, ChevronRight, Coffee, Brain, Zap, X, Laptop, GraduationCap, FileText, Lightbulb, TrendingUp, Award, Users, Heart } from 'lucide-react';
import AdminRoute from './components/AdminRoute';
import AdminDashboard from './components/AdminDashboard';
import AdminProfile from './components/AdminProfile';
import BlogHome from './components/BlogHome';
import BlogPost from './components/BlogPost';
import ProfilePage from './components/ProfilePage';
import WritePost from './components/WritePost';  // ここに追加

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<BlogHome />} />
        <Route path="/post/:id" element={<BlogPost />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/write" element={<WritePost />} />  {/* ここに追加 */}
        <Route path="/admin" element={
          <AdminRoute>
            <AdminDashboard />
          </AdminRoute>
        } />
        <Route path="/admin/profile" element={
          <AdminRoute>
            <AdminProfile />
          </AdminRoute>
        } />
      </Routes>
    </Router>
  );
}

export default App;

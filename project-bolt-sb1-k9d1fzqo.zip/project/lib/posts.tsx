// lib/posts.tsx
import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { remark } from 'remark';
import html from 'remark-html';

const postsDirectory = path.join(process.cwd(), 'content', 'posts');
const profilePath = path.join(process.cwd(), 'content', 'profile.md');

export type PostMeta = {
  title?: string;
  date?: string; // ISO string for serialization
  [key: string]: any;
};

export type Post = {
  slug: string;
  meta: PostMeta;
  contentHtml: string;
};

// ─── ブログ記事 ─────────────────────────

// すべての記事の slug を取得（ファイル名から）
export function getPostSlugs(): string[] {
  return fs.readdirSync(postsDirectory).filter((file) => file.endsWith('.md'));
}

// ページ側互換用エイリアス（もし参照があるなら）
export const getAllPostSlugs = getPostSlugs;

// slug を元に1つの記事データを取得（非同期版）
export async function getPostBySlug(slug: string): Promise<Post> {
  const realSlug = slug.replace(/\.md$/, '');
  const fullPath = path.join(postsDirectory, `${realSlug}.md`);
  const fileContents = fs.readFileSync(fullPath, 'utf8');
  const { data, content } = matter(fileContents);

  const processedContent = await remark().use(html).process(content);
  const contentHtml = processedContent.toString();

  // Normalize meta and ensure date is a string (ISO) for serialization
  const metaRaw: Record<string, any> = data || {};
  const meta: PostMeta = { ...metaRaw };

  if (metaRaw.date) {
    // If date is already a string, keep it; otherwise convert Date -> ISO string
    const parsed = new Date(metaRaw.date);
    if (!isNaN(parsed.getTime())) {
      meta.date = parsed.toISOString();
    } else if (typeof metaRaw.date === 'string') {
      meta.date = metaRaw.date;
    }
  }

  return {
    slug: realSlug,
    meta,
    contentHtml,
  };
}

// 全記事を取得（一覧ページ用）
// ※ profile.md のように「記事一覧に出したくないもの」は
//    フロントマターに `exclude: true` を追加しておく
export async function getAllPosts(): Promise<Post[]> {
  const slugs = getPostSlugs();

  // Promise.all で必ず解決済みの配列を返す
  const posts = await Promise.all(slugs.map((slug) => getPostBySlug(slug.replace(/\.md$/, ''))));

  // Filter & sort (note: meta.date is ISO string now)
  return posts
    .filter((post) => !post.meta.exclude)
    .sort((a, b) => {
      const ta = a.meta.date ? new Date(a.meta.date).getTime() : 0;
      const tb = b.meta.date ? new Date(b.meta.date).getTime() : 0;
      return tb - ta;
    });
}

// ─── プロフィール情報 ─────────────────────────
export async function getProfile() {
  const fileContents = fs.readFileSync(profilePath, 'utf8');
  const { data, content } = matter(fileContents);

  const processedContent = await remark().use(html).process(content);
  const contentHtml = processedContent.toString();

  const metaRaw: Record<string, any> = data || {};
  const meta: Record<string, any> = { ...metaRaw };

  if (metaRaw.date) {
    const parsed = new Date(metaRaw.date);
    if (!isNaN(parsed.getTime())) {
      meta.date = parsed.toISOString();
    }
  }

  return {
    ...meta,
    contentHtml,
  };
}

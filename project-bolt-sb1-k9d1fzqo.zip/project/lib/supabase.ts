// lib/supabase.ts
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';

if (!supabaseUrl || !supabaseAnonKey) {
  // ビルド時に落としたくない場合は警告だけ出す（本番では env が必須）
  console.warn('Supabase: NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY is not set.');
}

export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseAnonKey);

/**
 * 型定義（あなたのテーブルに合わせて必要なら拡張してください）
 */
export type BlogPost = {
  id: string;
  title: string;
  excerpt?: string;
  content?: string;
  image_url?: string;
  tags?: string[];          // supabase では text[] のことが多い
  category?: string;
  featured?: boolean;
  published?: boolean;
  created_at?: string;      // ISO 文字列にしておくと JSON serialize 安全
  read_time?: string;
};

export type Profile = {
  id?: string;
  display_name?: string;
  short_bio?: string;
  avatar_url?: string;
  logo_url?: string;
  github_url?: string;
  twitter_url?: string;
};

export type FooterSettings = {
  contact_email?: string;
  privacy_policy_url?: string;
  company_description?: string;
};

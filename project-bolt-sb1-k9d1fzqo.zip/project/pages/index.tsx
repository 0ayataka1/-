// pages/index.tsx
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, BookOpen, Clock, Target, User, Github, Twitter, Linkedin, Calendar, Tag, ChevronRight, Coffee, Brain, Zap, X, Laptop, GraduationCap, FileText, Lightbulb, TrendingUp, Award, Users, Heart, ChefHat, Scissors, Camera, Palette, Sparkles, Star, Gift } from 'lucide-react';
import { supabase, BlogPost, Profile, FooterSettings } from '../lib/supabase';

export default function BlogHome() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [footerSettings, setFooterSettings] = useState<FooterSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    fetchPosts();
    fetchProfile();
    fetchFooterSettings();
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('published', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('記事の取得に失敗しました:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .limit(1);

      if (error) {
        console.error('プロフィールの取得に失敗しました:', error);
      } else if (data && data.length > 0) {
        setProfile(data[0]);
      } else {
        setProfile(null);
      }
    } catch (error) {
      console.error('プロフィールの取得に失敗しました:', error);
    }
  };

  const fetchFooterSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('footer_settings')
        .select('*')
        .limit(1);

      if (error) {
        console.warn('フッター設定の取得をスキップしました:', error.message);
      } else if (data && data.length > 0) {
        setFooterSettings(data[0]);
      }
    } catch (error) {
      console.warn('フッター設定の取得をスキップしました:', error);
    }
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'learning-log': return <Brain className="w-4 h-4" />;
      case 'guide': return <Camera className="w-4 h-4" />;
      case 'tools': return <Heart className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'learning-log': return '学びと効率化';
      case 'guide': return '発信と表現';
      case 'tools': return '暮らしの工夫';
      default: return category;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'learning-log': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'guide': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'tools': return 'bg-green-50 text-green-700 border-green-200';
      default: return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  const featuredPost = posts.find(post => post.featured);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  return (
  <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
    <header className="bg-white shadow-md py-4 px-6">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <h1 className="text-xl font-bold text-gray-800">サイト名</h1>
        <nav className="space-x-4">
          <a href="#home" className="text-gray-600 hover:text-gray-800">Home</a>
          <a href="#about" className="text-gray-600 hover:text-gray-800">About</a>
          <a href="#contact" className="text-gray-600 hover:text-gray-800">Contact</a>
        </nav>
      </div>
    </header>

    <main className="max-w-6xl mx-auto py-10 px-6">
      <section id="home" className="mb-16">
        <h2 className="text-2xl font-bold mb-4">ホーム</h2>
        <p className="text-gray-700">ここにホームのコンテンツが入ります。</p>
      </section>

      <section id="about" className="mb-16">
        <h2 className="text-2xl font-bold mb-4">アバウト</h2>
        <p className="text-gray-700">ここにアバウトのコンテンツが入ります。</p>
      </section>

      <section id="contact" className="mb-16">
        <h2 className="text-2xl font-bold mb-4">コンタクト</h2>
        <p className="text-gray-700">ここにコンタクトのコンテンツが入ります。</p>
      </section>
    </main>

    <footer className="bg-gray-800 text-white py-6">
      <div className="max-w-6xl mx-auto px-6 text-center">
        <p>&copy; 2025 あやたか. All rights reserved.</p>
      </div>
    </footer>
  </div>
);
}

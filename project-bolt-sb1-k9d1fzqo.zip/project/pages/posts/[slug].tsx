// pages/posts/[slug].tsx
import { GetStaticPaths, GetStaticProps } from 'next';
import Head from 'next/head';
import React from 'react';
import { getAllPostSlugs, getPostBySlug, Post } from '../../lib/posts';

type PostProps = {
  post: Post;
};

export default function PostPage({ post }: PostProps) {
  const title = post?.meta?.title ?? post?.slug ?? 'Untitled';
  const description = post?.meta?.description ?? '';
  const dateIso = post?.meta?.date;
  let formattedDate = '';

  if (typeof dateIso === 'string' && dateIso) {
    const d = new Date(dateIso);
    if (!isNaN(d.getTime())) {
      formattedDate = d.toLocaleDateString(); // 必要ならロケール指定も可能
    } else {
      formattedDate = dateIso;
    }
  }

  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
      </Head>

      <article>
        <h1>{title}</h1>
        {formattedDate && <p>{formattedDate}</p>}
        <div dangerouslySetInnerHTML={{ __html: post?.contentHtml ?? '' }} />
      </article>
    </>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  // getAllPostSlugs() は同期でファイル名リストを返す想定（"foo.md"）
  const slugs = getAllPostSlugs().map((s) => s.replace(/\.md$/, ''));

  const paths = slugs.map((slug) => ({ params: { slug } }));

  return {
    paths,
    fallback: false,
  };
};

export const getStaticProps: GetStaticProps<PostProps> = async (context) => {
  const slug = context.params?.slug;
  if (typeof slug !== 'string') {
    return { notFound: true };
  }

  const post = await getPostBySlug(slug);

  return {
    props: {
      post,
    },
  };
};

import { GetStaticProps } from 'next';
import { getProfile } from '../lib/posts';

type ProfileProps = {
  name: string;
  title: string;
  bio: string;
  avatar: string;
  twitter?: string;
  github?: string;
  contentHtml: string;
};

export default function Profile({ name, title, bio, avatar, twitter, github, contentHtml }: ProfileProps) {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="flex items-center space-x-6 mb-6">
        <img src={avatar} alt={name} className="w-20 h-20 rounded-full" />
        <div>
          <h1 className="text-2xl font-bold">{name}</h1>
          <p className="text-sm text-gray-600">{title}</p>
        </div>
      </div>
      <p className="text-gray-700 mb-6">{bio}</p>
      <div className="prose" dangerouslySetInnerHTML={{ __html: contentHtml }} />
      <div className="flex space-x-4 mt-6">
        {twitter && <a href={twitter} target="_blank">Twitter</a>}
        {github && <a href={github} target="_blank">GitHub</a>}
      </div>
    </div>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  const profile = await getProfile();
  return {
    props: profile,
  };
};

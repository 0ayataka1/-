// tailwind.config.js
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './app/**/*.{js,ts,jsx,tsx}',        // Next.js app router を使っている場合
    './components/**/*.{js,ts,jsx,tsx}',
    './src/**/*.{js,ts,jsx,tsx}',        // src 配下も使っているなら
    './lib/**/*.{js,ts,jsx,tsx}',        // あれば
    './styles/**/*.{css}',               // CSS 内のクラスを含めたい場合
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
